import React from "react";
import { Container } from "../../styles/GlobalStyles";

const NoPage = () => {
    return (
      <Container>
        <h1>404</h1>
      </Container>
    );
  };
  
export default NoPage;
