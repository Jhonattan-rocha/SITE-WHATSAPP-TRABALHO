export const baseURL = '10.150.53.228';
export const ApiPort = 9003;
export const Socket_port = 9004;