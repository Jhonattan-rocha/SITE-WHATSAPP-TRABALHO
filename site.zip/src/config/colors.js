export const primarycolor = `#C3073F`;
export const primarydarkcolor = `#1A1A1D`;

export const sucessesColor = `#0197F6`;
export const infoColor = `#0197F6`;
export const errorColor = `#F2AF29`;
export const warningColor = `#F2AF29`;

export const white = "#FFFFFF";
export const azulescuro = "#050A30";
export const azulclaro = "#233DFF";

